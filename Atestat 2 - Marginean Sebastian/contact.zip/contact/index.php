<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="stylesc.css">
    <title>Contact Us Form In Php</title>
</head>
<body>
    <nav>
        <ul class="topnav" id="dropdownClick">
            <li><a class="active" href="index.html">Acasă</a></li>
            <li><a href="noutati.html">Noutăţi</a></li>
            <li><a href="index.php">Contact</a></li>
            <li><a href="despre.html">Despre</a></li>
            <li class="dropdownIcon"><a href="javascript:void(0);" onclick="dropdownMenu()">&#9776;</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card mt-5">
                    <div class="card-title">
                        <h2 class="text-center py-2"> Contact Us </h2>
                        <hr>
                        <?php 
                            $Msg = "";
                            if(isset($_GET['error']))
                            {
                                $Msg = " Please Fill in the Blanks ";
                                echo '<div class="alert alert-danger">'.$Msg.'</div>';
                            }

                            if(isset($_GET['success']))
                            {
                                $Msg = " Your Message Has Been Sent ";
                                echo '<div class="alert alert-success">'.$Msg.'</div>';
                            }
                        
                        ?>
                    </div>
                    <div class="card-body">
                        <form action="process.php" method="post">
                            <input type="text" name="UName" placeholder="Numele tau" class="form-control mb-2">
                            <br>
                            <br>
                            <input type="email" name="Email" placeholder="Email" class="form-control mb-2">
                            <br>
                            <br>
                            <input type="text" name="Subject" placeholder="Subiectul" class="form-control mb-2">
                            <br>
                            <br>
                            <textarea name="msg" class="form-control mb-2" placeholder="Mesajul"></textarea>
                            <br>
                            <br>
                            <button class="btn btn-success" name="btn-send"> Trimite </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
   
   

<footer class="foot">
    <div class="row">
        <div class="col-12">
            <h1>Follow me</h1>
            <div class="Social-media">
                <a href="https://www.facebook.com/sebastian.marginean.39"><img src="rsz_2facebook.png" ></a>
                <a href="https://www.instagram.com/marginean.sebi15/"><img src="rsz_instagram.png"></a>
            </div>
            <h3>© 2020-2021 All rights reserved</h3>
            <h4>Webdesign by Marginean Sebastian</h4>
        </div>
    </div>
    </footer>
    
    
<script>  
    function dropdownMenu() {
        var x = document.getElementById("dropdownClick");
        if (x.className === "topnav") {
            x.className += " responsive";
            /*change topnav to topnav.responsive*/
        } else {
            x.className = "topnav";
        }
    }
</script>  
</body>
</html>